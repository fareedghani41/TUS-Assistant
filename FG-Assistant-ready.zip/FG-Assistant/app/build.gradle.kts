plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.faridghani.fgassistant"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.faridghani.fgassistant"
        minSdk = 26   // CallScreeningService needs 24+, notification channels need 26+
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildFeatures { viewBinding = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.0")
    implementation("androidx.lifecycle:lifecycle-service:2.8.0")

    // Camera
    implementation("androidx.camera:camera-core:1.3.4")
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("androidx.camera:camera-video:1.3.4")

    // Wake word (on-device) — pick one:
    // implementation("ai.picovoice:porcupine-android:3.0.2")
    // implementation("com.alphacephei:vosk-android:0.3.47")

    // Gemini (voice, search grounding) — use the official Android SDK
    // once published, or REST calls via OkHttp to the same
    // /v1/live or /v1/models endpoints Mark LIV's main.py uses.
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    implementation("org.json:json:20240303")
}
