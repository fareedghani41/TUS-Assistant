package com.faridghani.fgassistant.core

import com.faridghani.fgassistant.controllers.*

/**
 * Takes a transcribed utterance (any language — STT handles that upstream)
 * and decides what to do. Wake word "FG" is stripped by WakeWordService
 * before this ever runs, so `text` here is just the command itself.
 */
class VoiceCommandProcessor(
    private val appController: AppController,
    private val fileController: FileController,
    private val cameraController: CameraController,
    private val messagingController: MessagingController,
    private val confirmation: ConfirmationManager,
    private val tts: TTSManager,
    private val trustedCallers: TrustedCallerPolicy
) {

    // Actions that cannot be undone or that touch another person's experience
    // (location, delete, uninstall) must go through ConfirmationManager.
    // Nothing destructive ever executes directly from this function.
    suspend fun handle(text: String, speakerId: String? = null) {
        val cmd = Intent.classify(text)

        when (cmd) {
            is Intent.DeleteFile -> confirmation.ask(
                prompt = "Delete karu '${cmd.name}'? Haan bolo to confirm.",
                onYes = { fileController.delete(cmd.name) }
            )

            is Intent.UninstallApp -> confirmation.ask(
                prompt = "'${cmd.appName}' uninstall karu? Haan bolo.",
                onYes = {
                    // Android shows its OWN system confirmation dialog on top of this —
                    // that one cannot be skipped, by design. We only add our own
                    // voice-confirm step before even triggering that OS prompt.
                    appController.requestUninstall(cmd.appName)
                }
            )

            is Intent.InstallApp -> confirmation.ask(
                prompt = "'${cmd.appName}' install karu Play Store se? Haan bolo.",
                onYes = { appController.openInstallFlow(cmd.appName) }
            )

            is Intent.ShareLocation -> {
                // Policy lives in TrustedCallerPolicy, not hardcoded here —
                // "only if my father asks" is a rule the user configures once
                // in Settings (see TrustedCallerPolicy.kt), matched by caller ID
                // on the current call/chat thread, not by whoever claims to be him.
                if (speakerId != null && trustedCallers.isTrusted(speakerId, role = "father")) {
                    messagingController.shareLiveLocation(speakerId)
                } else {
                    tts.say("Sorry, main location share nahi kar sakta is contact ke sath.")
                }
            }

            is Intent.TakePhoto -> cameraController.capturePhoto(front = cmd.selfie)
            is Intent.TakeVideo -> cameraController.captureVideo(front = cmd.selfie)
            is Intent.Torch -> cameraController.toggleTorch(cmd.on)

            is Intent.SendMessage -> messagingController.send(
                app = cmd.app, to = cmd.contact, body = cmd.body
            )

            is Intent.WebSearch -> messagingController.webSearch(cmd.query, tts)

            is Intent.RenameFile -> fileController.rename(cmd.from, cmd.to)
            is Intent.CreateFile -> fileController.create(cmd.name, cmd.type)

            is Intent.OpenApp -> appController.launch(cmd.appName)

            is Intent.Unknown -> tts.say("Samajh nahi aaya, dobara boliye.")
        }
    }
}
