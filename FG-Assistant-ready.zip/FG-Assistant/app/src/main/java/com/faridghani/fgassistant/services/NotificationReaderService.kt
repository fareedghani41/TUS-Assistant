package com.faridghani.fgassistant.services

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * User must manually grant this in Settings > Apps > Special access >
 * Notification access — Android will not let any app or ADB command grant
 * it silently, by design (it's one of the most sensitive permissions
 * there is: it can read the content of every notification on the phone).
 *
 * Scope here is deliberately narrow: only reacts to WhatsApp's package,
 * only to understand that a new message arrived (and, for audio notes,
 * trigger playback+understanding) — never reads/stores notifications
 * from other apps.
 */
class NotificationReaderService : NotificationListenerService() {

    private val whatsappPackage = "com.whatsapp"

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != whatsappPackage) return

        val extras = sbn.notification.extras
        val sender = extras.getString("android.title") ?: return
        val isAudioNote = extras.getString("android.text")?.contains("audio", true) == true

        if (isAudioNote) {
            // TODO: WhatsApp notifications don't carry the actual audio file —
            // only that one arrived. Playing/transcribing it requires either
            // (a) the user opening the chat (then FG reads it via
            // Accessibility Service content description), or (b) WhatsApp
            // Business API webhook if this becomes a business account.
            // Flag honestly: full auto-play of a regular WhatsApp voice note
            // without opening the app is not something the notification
            // alone gives us.
        } else {
            // Text message: content is NOT included in the notification
            // extras on modern WhatsApp for privacy reasons — only that a
            // message arrived. To read/reply to the actual text, this needs
            // an AccessibilityService reading the open chat screen, which
            // requires its own explicit user grant (Settings > Accessibility)
            // and should announce itself to the OTHER person via
            // MessagingController.DISCLOSURE_PREFIX before replying.
        }
    }
}
