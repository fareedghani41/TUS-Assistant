package com.faridghani.fgassistant.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.faridghani.fgassistant.services.WakeWordService

/**
 * First run walks through EVERY permission explicitly (mic, contacts,
 * camera, SMS, storage) — Android shows its own grant dialog for each,
 * one at a time. Also links out to the two settings screens Android
 * requires to be granted manually: Notification Access and Accessibility.
 * There is no API to pre-grant either of these — that's intentional on
 * Google's part, since both are high-trust permissions.
 */
class MainActivity : ComponentActivity() {

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) {
            startForegroundService(Intent(this, WakeWordService::class.java))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestCorePermissions()
        // TODO: Compose/XML UI — onboarding steps, voice picker (TTSManager.Voice),
        // trusted-contacts setup (father's number for ShareLocation),
        // links to Notification Access + Accessibility settings pages,
        // memory viewer (parallels Mark LIV's Memory Panel).
    }

    private fun requestCorePermissions() {
        permissionLauncher.launch(
            arrayOf(
                android.Manifest.permission.RECORD_AUDIO,
                android.Manifest.permission.CAMERA,
                android.Manifest.permission.READ_CONTACTS,
                android.Manifest.permission.READ_PHONE_STATE,
                android.Manifest.permission.SEND_SMS,
                android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.POST_NOTIFICATIONS
            )
        )
    }
}
