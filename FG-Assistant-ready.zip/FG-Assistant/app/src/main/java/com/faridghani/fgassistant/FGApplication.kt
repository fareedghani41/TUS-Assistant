package com.faridghani.fgassistant

import android.app.Application
import com.faridghani.fgassistant.core.MemoryStore
import com.faridghani.fgassistant.core.TrustedCallerPolicy

class FGApplication : Application() {

    lateinit var memory: MemoryStore
        private set
    lateinit var trustedCallers: TrustedCallerPolicy
        private set

    override fun onCreate() {
        super.onCreate()
        memory = MemoryStore(this)
        trustedCallers = TrustedCallerPolicy(this)
    }
}
