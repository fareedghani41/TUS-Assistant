package com.faridghani.fgassistant.core

import android.content.Context

/**
 * "Only share location if my father asks" — this is matched against the
 * ACTUAL contact/phone-number/WhatsApp-thread the request came in on
 * (set once in Settings > Trusted People), never against a name the
 * speaker claims out loud. Anyone can SAY "I'm your father" over the
 * phone; a verified contact ID can't be faked that way.
 *
 * Voice alone is NOT used to verify identity here — voiceprint spoofing
 * is easy and this gates something sensitive (your live location).
 */
class TrustedCallerPolicy(private val context: Context) {

    // contactId (phone number / WhatsApp JID) -> role, set via Settings UI
    private val trusted: Map<String, String> = loadFromSettings()

    fun isTrusted(contactId: String, role: String): Boolean {
        return trusted[contactId]?.equals(role, ignoreCase = true) == true
    }

    private fun loadFromSettings(): Map<String, String> {
        // TODO: read from EncryptedSharedPreferences, populated by a
        // one-time "who is your father's number?" setup screen.
        return emptyMap()
    }
}
