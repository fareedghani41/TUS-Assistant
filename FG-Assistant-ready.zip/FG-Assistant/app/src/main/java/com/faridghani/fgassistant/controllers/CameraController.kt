package com.faridghani.fgassistant.controllers

import android.content.Context
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.Recorder
import androidx.camera.video.VideoCapture
import androidx.lifecycle.LifecycleOwner

/**
 * Voice-triggered capture. Note: Android requires the camera to actually
 * open (sensor activates) which on most OEM skins briefly shows a camera
 * indicator dot in the status bar — this is an OS privacy signal that
 * cannot be suppressed by any app, by design, since Android 12.
 */
class CameraController(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner
) {
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var cameraProvider: ProcessCameraProvider? = null

    fun capturePhoto(front: Boolean) {
        bindCamera(front)
        val output = FileOutputHelper.newImageFile(context)
        imageCapture?.takePicture(
            output, Runnable::run,
            FileOutputHelper.imageCallback(output)
        )
    }

    fun captureVideo(front: Boolean) {
        bindCamera(front, video = true)
        val output = FileOutputHelper.newVideoFile(context)
        videoCapture?.let { FileOutputHelper.startRecording(it, output) }
    }

    fun toggleTorch(on: Boolean) {
        // Torch requires an active camera session; bind a minimal
        // preview-only use case if one isn't already running.
        bindCamera(front = false)
        cameraProvider?.let { /* camera.cameraControl.enableTorch(on) once bound */ }
    }

    private fun bindCamera(front: Boolean, video: Boolean = false) {
        val selector = if (front) CameraSelector.DEFAULT_FRONT_CAMERA
                        else CameraSelector.DEFAULT_BACK_CAMERA
        // TODO: full CameraX provider.bindToLifecycle(...) wiring with
        // imageCapture / videoCapture use cases attached to `selector`.
    }
}

/** Placeholder — real implementation writes to MediaStore.Images/Video. */
private object FileOutputHelper {
    fun newImageFile(context: Context): ImageCapture.OutputFileOptions =
        TODO("Build via MediaStore.Images.Media content values")
    fun newVideoFile(context: Context): Any = TODO("Build via MediaStore.Video.Media")
    fun imageCallback(output: ImageCapture.OutputFileOptions): ImageCapture.OnImageSavedCallback =
        TODO("Standard success/error callback")
    fun startRecording(videoCapture: VideoCapture<Recorder>, output: Any): Unit =
        TODO("Recorder.prepareRecording(...).start()")
}
