package com.faridghani.fgassistant.controllers

import android.content.Context
import android.content.Intent
import android.net.Uri

/**
 * IMPORTANT REALITY CHECK (not a limitation of this code, a limitation of
 * Android itself, true for every app including Mark LIV's desktop OS-level
 * tools): a normal app CANNOT silently install or uninstall another app.
 * Starting Android 8, every install/uninstall must show the system's own
 * confirmation screen with a visible Cancel button — no permission or API
 * removes that. Device-owner / MDM mode can skip it, but that requires
 * enrolling the phone as a managed device, which is a deliberate, visible
 * setup step the owner does once — not something this app can do to itself.
 *
 * So: FG can DRIVE the OS prompt (fill it in, launch it, voice-confirm
 * before even opening it) but cannot suppress the OS's own confirmation.
 */
class AppController(private val context: Context) {

    fun requestUninstall(appName: String) {
        val pkg = resolvePackageName(appName) ?: return
        val intent = Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        context.startActivity(intent) // OS shows its own confirm dialog here
    }

    fun openInstallFlow(appName: String) {
        // Opens Play Store listing — actual install tap is the user's,
        // same as it would be if they searched for it themselves.
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=$appName"))
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        context.startActivity(intent)
    }

    fun launch(appName: String) {
        val pkg = resolvePackageName(appName) ?: return
        context.packageManager.getLaunchIntentForPackage(pkg)?.let {
            it.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(it)
        }
    }

    private fun resolvePackageName(appName: String): String? {
        val pm = context.packageManager
        val apps = pm.getInstalledApplications(0)
        return apps.firstOrNull {
            pm.getApplicationLabel(it).toString().contains(appName, ignoreCase = true)
        }?.packageName
    }
}
