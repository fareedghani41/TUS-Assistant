package com.faridghani.fgassistant.services

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.faridghani.fgassistant.FGApplication
import com.faridghani.fgassistant.R

/**
 * Runs continuously in the background listening for "FG". Android requires
 * a persistent, visible notification for any foreground microphone service
 * — this is a non-negotiable OS privacy guarantee since Android 9, not a
 * choice this app makes. The notification can be low-priority/minimized
 * but never fully hidden.
 *
 * Wake word detection itself should use an on-device engine (Porcupine,
 * or Vosk's small model) rather than Android's SpeechRecognizer, because
 * SpeechRecognizer streams audio to Google's servers continuously, which
 * is both a privacy problem and a battery/data problem for always-on use.
 * An on-device wake word model only wakes the full STT pipeline (and
 * starts actually sending audio anywhere) once "FG" is detected locally.
 */
class WakeWordService : Service() {

    private val channelId = "fg_listening_channel"

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(1, buildNotification())
        startWakeWordEngine()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    private fun startWakeWordEngine() {
        // TODO: initialize Porcupine/Vosk with a custom "FG" keyword model,
        // register a callback that, on detection, briefly opens the full
        // STT stream (Gemini Live or SpeechRecognizer) to capture the
        // actual command, then hands text to VoiceCommandProcessor.handle().
        // Auto-sleep after N seconds of silence, mirroring Mark LIV's
        // wake-word auto-sleep behavior.
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, channelId)
            .setContentTitle("FG is listening")
            .setContentText("Say \"FG\" to give a command")
            .setSmallIcon(R.drawable.ic_mic)
            .setOngoing(true)
            .build()

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            channelId, "FG Background Listening", NotificationManager.IMPORTANCE_LOW
        )
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(channel)
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
