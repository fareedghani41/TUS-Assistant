package com.faridghani.fgassistant.controllers

import android.content.Context
import java.io.File

/**
 * Create/rename/delete only ever run AFTER ConfirmationManager has gotten
 * a verbal "yes" (see VoiceCommandProcessor). This class does no asking
 * itself — it trusts the caller already confirmed.
 */
class FileController(private val context: Context) {

    private val baseDir: File
        get() = context.getExternalFilesDir(null) ?: context.filesDir

    fun create(name: String, type: String) {
        val file = File(baseDir, if (name.contains(".")) name else "$name.$type")
        if (!file.exists()) file.createNewFile()
    }

    fun rename(from: String, to: String) {
        val src = File(baseDir, from)
        if (src.exists()) src.renameTo(File(baseDir, to))
    }

    fun delete(name: String) {
        val target = File(baseDir, name)
        if (target.exists()) target.delete()
        // TODO: for files outside app-scoped storage (e.g. Downloads),
        // use MediaStore.createDeleteRequest() on Android 11+, which
        // triggers the OS's own one-tap confirmation — same pattern as
        // AppController's uninstall flow.
    }
}
