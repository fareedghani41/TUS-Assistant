package com.faridghani.fgassistant.core

/**
 * Lightweight local classifier for common commands (fast, offline, no API call).
 * Anything that doesn't match a pattern falls through to Gemini for free-form
 * understanding (see GeminiRouter.kt) before landing on Unknown.
 */
sealed class Intent {
    data class DeleteFile(val name: String) : Intent()
    data class RenameFile(val from: String, val to: String) : Intent()
    data class CreateFile(val name: String, val type: String) : Intent()
    data class UninstallApp(val appName: String) : Intent()
    data class InstallApp(val appName: String) : Intent()
    data class OpenApp(val appName: String) : Intent()
    data class ShareLocation(val withWhom: String) : Intent()
    data class TakePhoto(val selfie: Boolean) : Intent()
    data class TakeVideo(val selfie: Boolean) : Intent()
    data class Torch(val on: Boolean) : Intent()
    data class SendMessage(val app: String, val contact: String, val body: String) : Intent()
    data class WebSearch(val query: String) : Intent()
    object Unknown : Intent()

    companion object {
        fun classify(text: String): Intent {
            val t = text.lowercase().trim()
            return when {
                t.startsWith("delete") -> DeleteFile(t.removePrefix("delete").trim())
                t.startsWith("uninstall") -> UninstallApp(t.removePrefix("uninstall").trim())
                t.startsWith("install") -> InstallApp(t.removePrefix("install").trim())
                t.startsWith("open") -> OpenApp(t.removePrefix("open").trim())
                t.contains("selfie") && t.contains("video") -> TakeVideo(selfie = true)
                t.contains("selfie") -> TakePhoto(selfie = true)
                t.contains("video") -> TakeVideo(selfie = false)
                t.contains("photo") || t.contains("picture") -> TakePhoto(selfie = false)
                t.contains("torch") || t.contains("flashlight") -> Torch(on = !t.contains("off"))
                t.contains("location") -> ShareLocation(withWhom = "")
                t.startsWith("search") -> WebSearch(t.removePrefix("search").trim())
                // TODO: SendMessage / RenameFile / CreateFile pattern matching,
                // then a GeminiRouter.classify(text) fallback for anything
                // that doesn't match a rule above.
                else -> Unknown
            }
        }
    }
}
