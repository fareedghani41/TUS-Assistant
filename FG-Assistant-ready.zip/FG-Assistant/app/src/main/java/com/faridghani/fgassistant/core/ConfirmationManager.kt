package com.faridghani.fgassistant.core

import com.faridghani.fgassistant.controllers.TTSManager

/**
 * Per your answer: destructive actions (delete, uninstall) must be spoken
 * back and confirmed with "yes" before they run. No button needed — this
 * stays voice-only, but it is never skipped, even under "no button" mode.
 *
 * Pattern borrowed from the Mark LIV reference project: the model/parser
 * cannot self-confirm. The YES has to come from a fresh recognized
 * utterance after the prompt, not from anything baked into the original command.
 */
class ConfirmationManager(private val tts: TTSManager, private val sttOnce: suspend () -> String) {

    suspend fun ask(prompt: String, onYes: () -> Unit, onNo: (() -> Unit)? = null) {
        tts.say(prompt)
        val reply = sttOnce().lowercase().trim()
        val affirmative = listOf("yes", "haan", "ha", "ji haan", "confirm", "do it")
        if (affirmative.any { reply.contains(it) }) {
            onYes()
        } else {
            tts.say("Theek hai, cancel kar diya.")
            onNo?.invoke()
        }
    }
}
