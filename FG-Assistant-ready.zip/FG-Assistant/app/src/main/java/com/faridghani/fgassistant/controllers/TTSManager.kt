package com.faridghani.fgassistant.controllers

import android.content.Context

/**
 * Wraps a natural TTS engine. Android's built-in TextToSpeech sounds robotic;
 * for the "clear, human, attractive" voice quality you asked for, route
 * through Gemini's native audio voices (same ones Mark LIV uses — Aoede,
 * Kore = female; Puck, Charon, Fenrir = male) or ElevenLabs if you want
 * even more natural prosody. Settings screen lets you pick + preview.
 */
class TTSManager(private val context: Context) {

    enum class Voice { FEMALE_AOEDE, FEMALE_KORE, MALE_PUCK, MALE_CHARON, MALE_FENRIR }

    var selectedVoice: Voice = Voice.FEMALE_AOEDE
    var language: String = "auto" // detected from last recognized utterance

    suspend fun say(text: String) {
        // TODO: stream `text` to Gemini Live API audio output using
        // `selectedVoice`, in `language`. Falls back to Android TextToSpeech
        // if offline / no network.
    }
}
