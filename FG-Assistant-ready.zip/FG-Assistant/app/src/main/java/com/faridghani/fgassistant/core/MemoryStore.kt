package com.faridghani.fgassistant.core

import android.content.Context
import org.json.JSONObject
import java.io.File

/**
 * Local-only persistent memory, same philosophy as Mark LIV's
 * memory/long_term.json: nothing deleted automatically, a bounded "core"
 * of recent/important facts is kept hot for prompt context, everything
 * else is searchable on demand. No cloud sync by default — add one
 * explicitly if you want cross-device memory later.
 */
class MemoryStore(context: Context) {

    private val file = File(context.filesDir, "fg_memory.json")
    private var data: JSONObject = if (file.exists())
        JSONObject(file.readText()) else JSONObject()

    fun remember(key: String, value: String) {
        data.put(key, value)
        persist()
    }

    fun recall(key: String): String? = data.optString(key).takeIf { it.isNotEmpty() }

    fun forget(key: String) {
        data.remove(key)
        persist()
    }

    fun allKeys(): List<String> = data.keys().asSequence().toList()

    private fun persist() = file.writeText(data.toString())
}
