package com.faridghani.fgassistant.services

import android.telecom.Call
import android.telecom.CallScreeningService

class FGCallScreeningService : CallScreeningService() {

    override fun onScreenCall(callDetails: Call.Details) {
        val number = callDetails.handle?.schemeSpecificPart ?: ""

        // Default: let every call through to Farid normally. FG only
        // steps in for calls he's set to auto-handle (e.g. "if I don't
        // pick up in 15s, FG answers and says who it is") — configured
        // in Settings, not a blanket always-answer-as-me behavior.
        val response = CallResponse.Builder()
            .setDisallowCall(false)
            .setRejectCall(false)
            .setSkipCallLog(false)
            .setSkipNotification(false)
            .build()

        respondToCall(callDetails, response)

        // TODO: if auto-answer is enabled for this number and no answer
        // within the configured delay, use TelecomManager to answer and
        // immediately play: "Hi, this is Farid Ghani's assistant, FG —
        // he's unavailable right now, how can I help?" via TTSManager,
        // then route the rest of the call through VoiceCommandProcessor.
    }
}
