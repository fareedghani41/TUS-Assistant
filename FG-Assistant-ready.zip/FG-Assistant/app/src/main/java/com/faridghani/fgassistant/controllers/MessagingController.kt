package com.faridghani.fgassistant.controllers

import android.content.Context
import android.content.Intent
import android.net.Uri

/**
 * Every message FG sends on Farid's behalf opens with a disclosure line,
 * per Farid's own instruction — this is not optional and not something
 * the voice command can turn off, by design (see DISCLOSURE_PREFIX).
 */
class MessagingController(private val context: Context) {

    companion object {
        const val DISCLOSURE_PREFIX = "Hi, I'm Farid Ghani's AI assistant (FG) — he's unavailable right now. "
    }

    fun send(app: String, contact: String, body: String) {
        val fullBody = DISCLOSURE_PREFIX + body
        when (app.lowercase()) {
            "whatsapp" -> sendWhatsApp(contact, fullBody)
            "sms" -> sendSms(contact, fullBody)
            else -> sendWhatsApp(contact, fullBody) // default
        }
    }

    private fun sendWhatsApp(phoneNumber: String, body: String) {
        val uri = Uri.parse("https://wa.me/$phoneNumber?text=${Uri.encode(body)}")
        val intent = Intent(Intent.ACTION_VIEW, uri)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        context.startActivity(intent)
        // NOTE: this opens WhatsApp with the message pre-filled; it does
        // NOT auto-tap send. A fully silent auto-send requires WhatsApp
        // Business API (Meta-hosted, needs business verification) —
        // regular WhatsApp gives no API for apps to send on a user's
        // behalf without that human tap, by Meta's own design.
    }

    private fun sendSms(phoneNumber: String, body: String) {
        // android.telephony.SmsManager.sendTextMessage — can send directly
        // if SEND_SMS is granted, no extra tap needed (SMS has no such
        // restriction the way WhatsApp does).
        // TODO: SmsManager.getDefault().sendTextMessage(phoneNumber, null, body, null, null)
    }

    fun webSearch(query: String, tts: TTSManager) {
        // TODO: call Gemini grounded search (or a search API) and have
        // tts.say(...) read back a short synthesized answer, same pattern
        // as the Mark LIV reference project's search mode.
    }

    fun shareLiveLocation(contactId: String) {
        // Only ever called after TrustedCallerPolicy.isTrusted() returns true.
        // TODO: FusedLocationProviderClient one-shot fetch, then send via
        // sendWhatsApp(contactId, DISCLOSURE_PREFIX + "Sharing his location: $mapsLink")
    }
}
